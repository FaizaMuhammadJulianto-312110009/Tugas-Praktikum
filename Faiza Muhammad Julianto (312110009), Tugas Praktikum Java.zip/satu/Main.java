public class Main {
    public static void main(String[] args) {
        Mahasiswa anton = new Mahasiswa();
        
        anton.nim = "10102020";
        anton.nama = "Anton Santoso";
        anton.jenisKelamin = "Laki-laki";
        anton.umur = 28;
        anton.alamat = "Bekasi Kota";
        anton.jurusan = "Informatika";

        anton.cetakInfo();
    }
}