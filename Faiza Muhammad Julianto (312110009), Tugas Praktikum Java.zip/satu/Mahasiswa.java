public class Mahasiswa extends Manusia {
    String nim;
    String jurusan;
    
    public void nim(String nim) {
        this.nim = nim;
    }
    
    public String getNim() {
        return nim;
    }
    
    public void jurusan(String jurusan) {
        this.jurusan = jurusan;
    }
    
    public String getJurusan() {
        return jurusan;
    }
    
    public void cetakInfo() {
        super.cetakInfo();
        System.out.println("NIM\t\t: " + nim);
        System.out.println("Jurusan\t\t: " + jurusan);
    }
}
